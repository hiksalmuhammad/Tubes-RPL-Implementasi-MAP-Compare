<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Popup Design</title> 
    <link rel="stylesheet" href="/css/style_report.css">
</head>
<body>
    <div class="container">
        <h1>REPORT DATA</h1>
        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
        <label for="floatingTextarea2"> </label>
        <button type="submit" class="btn" onclick="openPopup()">Submit</button>
        <div class="popup" id="popup">
            <img src="/img/check.png">
            <h2>Thank You!</h2>
            <p>Your report has been successfully sent. Thanks!</p>
            <button type="button" onclick="closePopup()"> <a href="/dashboard"> Ok</a> </button>
        </div>
    </div>



<script>
let popup = document.getElementById("popup");

function openPopup(){
    popup.classList.add("open-popup");
}

function closePopup(){
    popup.classList.remove("open-popup");
}
</script>
</body>
</html>