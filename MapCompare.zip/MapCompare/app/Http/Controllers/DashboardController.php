<?php

namespace App\Http\Controllers;

use App\Models\Report;
use App\Models\DetailNegara;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    //
    public function index()
    {
        
        $user = Auth::user();
        $detail_negara = DetailNegara::all();

        return view('dashboard', [
            'user' => $user,
            'detail_negara' => $detail_negara,

        ]);
    }
    
    public function indexGuest()
    {
        
        $detail_negara = DetailNegara::all();

        return view('dashboard', [
            
            'detail_negara' => $detail_negara,

        ]);
    }

    public function report_action(Request $request)
    {
        //ngambil data user yang saat ini login dari tabel user
        $user = Auth::user();

        //ngambil semua data dari tabel report
        $report = Report::all();

        //ngambil semua data dari tabel detailnegara
        $detail_negara = DetailNegara::all();

        $newReport = new Report([
            'report' => $request->reportdata,
            'id_user' => Auth::id(),
        ]);
        $newReport->save();

        return view('dashboard', [
            'user' => $user,
            'detail_negara' => $detail_negara
        ]);
    }

    public function search(Request $request)
    {
        $hasilSearch = DetailNegara::all();

        if($request->has('search'))
        {
            $hasilSearch->where('name','like','%'.$request->search.'%');
        }

        return view('dashboard',[
            'hasilSearch'=> $hasilSearch->get(),
        ]);
    }

}
