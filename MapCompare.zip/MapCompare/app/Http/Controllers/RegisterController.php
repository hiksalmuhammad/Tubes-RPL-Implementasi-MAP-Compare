<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
// untuk menggunakan fungsi Hash
use Illuminate\support\facades\Hash;

class RegisterController extends Controller
{
    //
    public function index()
    {
        return view('register',[
            'title' => 'Register',
            'active' => 'register'
        ]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'username' => ['required', 'min:3', 'max:255', 'unique:users'],
            'email' => 'required|email:dns|unique:users',
            'password' => 'required|min:5|max:255'
        ]);

        // untuk mengenkripsi password
        // $validatedData['password'] =bcrypt($validatedData['password']);

        // untuk mengenkripsi password menggunakan hash
        $validatedData['password'] = Hash::make($validatedData['password']);

        User::create($validatedData);

        // untuk menampilkan notifikasi bila registrasi success
        $request->session()->flash('success','Registration successfull!');

        // redirect atau kembali ke halaman login
        return redirect('/');
    }
}
