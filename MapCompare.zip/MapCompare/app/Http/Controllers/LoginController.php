<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    //
    public function index()
    {
        return view('login',[
            'title' => 'Login',
            'active' => 'login'
        ]);


    }

    public function authenticate(Request $request)
    {
        // untuk memvalidasi, sama seperti pada saat register
        $credentials = $request->validate([
            'email' => 'required|email:dns',
            'password' => 'required'
        ]);

        // untuk mengauthentifikasi data
        if(Auth::attempt($credentials)){
            $request->session()->regenerate();
            return redirect()->intended('/dashboard');
        }

        // nampilin notifikasi login error apa engga
        return back()->with('loginError','login failed!');


    }

    //untuk logout
    public function logout(Request $request)
    {
        Auth::logout();
    
        $request->session()->invalidate();
    
        $request->session()->regenerateToken();
    
        return redirect('/');
    }


}
