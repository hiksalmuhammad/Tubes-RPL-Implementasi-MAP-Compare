<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DashboardReportController;
use App\Http\Controllers\DashboardUserController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('login');
// });

// login
Route::get('/',[LoginController::class, 'index']);
Route::post('/',[LoginController::class, 'authenticate']);

//login guest
Route::get('/homeGuest', function () {
    return view('homeGuest');
});

//logout
Route::post('/logout',[LoginController::class, 'logout']);

// register
Route::get('/register',[RegisterController::class, 'index']);
Route::post('/register',[RegisterController::class, 'store']);

// dashboard, ini home
Route::get('/dashboard',[DashboardController::class, 'index']);
Route::get('/dashboard/search',[DashboardController::class, 'search']);

//home guest
Route::get('/homeGuest',[DashboardController::class, 'indexGuest']);

//report
Route::post('/report',[DashboardController::class, 'report_action'])
    ->name('report.action');

//report
Route::get('/report', function () {
    return view('report');
});



//dashboard real
Route::get('/dashboard_real', function () {
    return view('dashboard_real.index');
});

//controller-resource, report
Route::resource('/dashboard_real/report', DashboardReportController::class)->middleware('auth');

//controller-resource, user
Route::resource('/dashboard_real/user', DashboardUserController::class)->middleware('auth');