

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

    <h1 class="h2"> Hello, <?php echo e(Auth()->user()->username); ?></h1>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_real.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aulia\OneDrive\Dokumen\kuliah\tutorLaravel\MapCompare\resources\views/dashboard_real/index.blade.php ENDPATH**/ ?>