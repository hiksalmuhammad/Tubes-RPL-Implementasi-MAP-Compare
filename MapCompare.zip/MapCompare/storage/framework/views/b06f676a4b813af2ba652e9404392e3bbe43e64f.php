<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style_dashboard.css" />
    <link rel="stylesheet" href="/css/searchBox.css" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <title>CompareMap</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg bg-dark">
        <div class="container-fluid">
            <div class="brand">
                <div class="firstname">compare</div>
                <div class="lastname">map</div>
            </div>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                    <li class="nav-item">
                        <a class="nav-link fs-4 text-light disabled" href="/dashboard_real">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link fs-4 text-light disabled" href="/report">Report</a>
                    </li>
                    
                </ul >
                
                
                <ul class="navbar-nav ms-auto ">
                    <li class="nav-item">
                        <h5 class="nav-link text-light fs-4 " > Selamat Datang </h5>
                    </li>
                    
                    <li class="nav-item">
                        <div class="nav-link">
                            <a href="/">Login</a>
                        </div>
                    </li>
                </ul>

            </div>
        </div>
    </nav>


    <!-- negara -->
    <div class="negara">

        <!-- //search box -->
        <div class="row">
            <div class="col-md-3 mt-2 ms-2">
                <form action="/dashboard/search" method="GET">
                <div class="input-group mb-3">
                    <input type="search" class="form-control" placeholder="Search...."  name="search" >
                    <button class="btn btn-outline-secondary btn-success text-white" type="submit">Search</button>
                </div>
                </form>
            </div>

        </div>
        
        
</body>

</html>
<?php /**PATH C:\Users\aulia\OneDrive\Dokumen\kuliah\tutorLaravel\MapCompare\resources\views/homeGuest.blade.php ENDPATH**/ ?>