<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6" href="#">CompareMap</a>

  <div class="navbar-nav">
    <div class="nav-item text-nowrap">
      <form action="/logout" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link px-3 btn btn-dark" >Logout</button>
      </form>
    </div>
  </div>
</header><?php /**PATH C:\Users\aulia\OneDrive\Dokumen\kuliah\tutorLaravel\MapCompare\resources\views/dashboard_real/layouts/header.blade.php ENDPATH**/ ?>